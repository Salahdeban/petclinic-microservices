package com.example.petclinic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PetClinicOwner {

    public static void main(String[] args) {

        SpringApplication.run(PetClinicOwner.class, args);
    }
}
